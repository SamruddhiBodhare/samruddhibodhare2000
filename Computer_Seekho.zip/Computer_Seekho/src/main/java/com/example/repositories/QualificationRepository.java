package com.example.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entities.Qualification;

public interface QualificationRepository extends JpaRepository <Qualification,Integer>{

}
