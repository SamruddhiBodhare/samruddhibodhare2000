package com.example.repositories;
import org.springframework.data.repository.CrudRepository;
import com.example.entities.Payment;

public interface PaymentRepository extends CrudRepository<Payment,Integer> {

}
