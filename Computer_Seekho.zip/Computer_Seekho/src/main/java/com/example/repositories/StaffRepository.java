package com.example.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.entities.Staff;

@Repository
public interface StaffRepository  extends CrudRepository<Staff,Integer>{
	@Query("SELECT s FROM Staff s WHERE s.email = :email AND s.password = :password")
    Optional<Staff> loginUser(@Param("email") String email, @Param("password") String password);
}
