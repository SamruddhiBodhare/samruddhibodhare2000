package com.example.repositories;

import org.springframework.data.repository.CrudRepository;

import com.example.entities.BatchInfo;

public interface BatchInfoRepository extends CrudRepository<BatchInfo,Integer> {


	
}
