package com.example.services;
import java.util.List;
import java.util.Optional;
import com.example.entities.Enquiry;


public interface EnquiryService {
	Enquiry addEnquiry(Enquiry c);
	List<Enquiry> getEnquiry();
	void delete(int id);
	Optional<Enquiry> getEnquiry(int id);
}
