package com.example.services;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entities.PlacementData;
import com.example.repositories.PlacementDataRepository;
@Service
public class PlacementDataService {

	@Autowired
	PlacementDataRepository repository; 
	public List<PlacementData> getPlacementData() {
		// TODO Auto-generated method stub
		return (List<PlacementData>) repository.findAll();
	}

	 
	public void delete(int id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

	 
	public Optional<PlacementData> getPlacementData(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id);
	}

	 
	public PlacementData addPlacementData(PlacementData c) {
		// TODO Auto-generated method stub
		return repository.save(c);
	}

}
