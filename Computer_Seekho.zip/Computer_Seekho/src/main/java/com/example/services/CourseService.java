package com.example.services;

import java.util.List;
import java.util.Optional;

import com.example.entities.Course;

public interface CourseService 
{
	Course addCourse(Course c);
	List<Course> getCourses();
	void delete(int id);
	Optional<Course> getCourse(int id);
	
}
