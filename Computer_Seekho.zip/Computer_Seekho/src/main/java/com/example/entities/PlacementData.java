package com.example.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class PlacementData {
	 private int placementdata_Id;
	    private int p_Id;
	    private int placement_Id;
	    private int company_Id;
	    private String designation;
	    private int batch_Id;
	    private String status;
	    @Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		public int getPlacementdata_Id() {
			return placementdata_Id;
		}
		public void setPlacementdata_Id(int placementdata_Id) {
			this.placementdata_Id = placementdata_Id;
		}
		public int getP_Id() {
			return p_Id;
		}
		public void setP_Id(int p_Id) {
			this.p_Id = p_Id;
		}
		public int getPlacement_Id() {
			return placement_Id;
		}
		public void setPlacement_Id(int placement_Id) {
			this.placement_Id = placement_Id;
		}
		public int getCompany_Id() {
			return company_Id;
		}
		public void setCompany_Id(int company_Id) {
			this.company_Id = company_Id;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public int getBatch_Id() {
			return batch_Id;
		}
		public void setBatch_Id(int batch_Id) {
			this.batch_Id = batch_Id;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
}

