package com.example.entities;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Staff")
public class Staff {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int staff_Id;
	public String password;
	public String username;
	public String name;
	public int designation_id;
	public int qualification_id;
	public String experience;
	public String contact_No;
	public String email;
	public String photo;
	public int location_id;
	public Date joining_date;
	public String recovery_name;
	public String recovery_passoword;
	public int role_id;
	public int getStaff_Id() {
		return staff_Id;
	}
	public void setStaff_Id(int staff_Id) {
		this.staff_Id = staff_Id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getname() {
		return name;
	}
	public void setname(String name) {
		name = name;
	}
	public int getDesignation_id() {
		return designation_id;
	}
	public void setDesignation_id(int designation_id) {
		this.designation_id = designation_id;
	}
	public int getQualification_id() {
		return qualification_id;
	}
	public void setQualification_id(int qualification_id) {
		this.qualification_id = qualification_id;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getContact_No() {
		return contact_No;
	}
	public void setContact_No(String contact_No) {
		this.contact_No = contact_No;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public int getLocation_id() {
		return location_id;
	}
	public void setLocation_id(int location_id) {
		this.location_id = location_id;
	}
	public Date getJoining_date() {
		return joining_date;
	}
	public void setJoining_date(Date joining_date) {
		this.joining_date = joining_date;
	}
	public String getRecovery_name() {
		return recovery_name;
	}
	public void setRecovery_name(String recovery_name) {
		this.recovery_name = recovery_name;
	}
	public String getRecovery_passoword() {
		return recovery_passoword;
	}
	public void setRecovery_passoword(String recovery_passoword) {
		this.recovery_passoword = recovery_passoword;
	}
	public int getRole_id() {
		return role_id;
	}
	public void setRole_id(int role_id) {
		this.role_id = role_id;
	}
	
}
