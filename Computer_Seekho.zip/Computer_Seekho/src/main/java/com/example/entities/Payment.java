package com.example.entities;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Payment {
    private int Payment_Id;
    private int Student_Id;
    private String Transaction_Id;
    private Date Date;
    private double Amount;
    private int Batch_Id;
    private int Payment_type_Id;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
	public int getPayment_Id() {
		return Payment_Id;
	}
	
	public void setPayment_Id(int payment_Id) {
		Payment_Id = payment_Id;
	}
	@Column
	public int getStudent_Id() {
		return Student_Id;
	}
	
	public void setStudent_Id(int student_Id) {
		Student_Id = student_Id;
	}
	@Column
	public String getTransaction_Id() {
		return Transaction_Id;
	}
	
	public void setTransaction_Id(String transaction_Id) {
		Transaction_Id = transaction_Id;
	}
	@Column
	public Date getDate() {
		return Date;
	}
	
	public void setDate(Date date) {
		Date = date;
	}
	@Column
	public double getAmount() {
		return Amount;
	}
	
	public void setAmount(double amount) {
		Amount = amount;
	}
	@Column
	public int getBatch_Id() {
		return Batch_Id;
	}
	
	public void setBatch_Id(int batch_Id) {
		Batch_Id = batch_Id;
	}
	@Column
	public int getPayment_type_Id() {
		return Payment_type_Id;
	}
	
	public void setPayment_type_Id(int payment_type_Id) {
		Payment_type_Id = payment_type_Id;
	}
}
