package com.example.controllers;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entities.Payment;
import com.example.services.PaymentService;

@RestController
@CrossOrigin("*")
@RequestMapping("api/Payment")
public class PaymentController {
	@Autowired
	private PaymentService Service;

    @PostMapping(value="/create")
    public ResponseEntity<Payment> createPayment(@RequestBody Payment Payment) {
        Payment createdPayment = Service.addPayment(Payment);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdPayment);
    }
    @GetMapping(value = "/ListAll")
	 public List<Payment> ListAll()
	 {
		  return Service.getPayment(); 
	 }
	 @GetMapping(value = "/{id}")
	 public Optional<Payment> getCours(@PathVariable int id)
	 {
		Optional<Payment> p=Service.getPayment(id);
		return p;
	 }
	
	 @DeleteMapping(value = "/{id}")
	 public void remove(@PathVariable int id)
	 {
		Service.delete(id);
	 }

}
